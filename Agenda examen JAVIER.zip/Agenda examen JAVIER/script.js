document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Evita que el formulario se recargue

    let name = document.getElementById("name").value.trim();
    let phone = document.getElementById("phone").value.trim();
    let email = document.getElementById("email").value.trim();

    if (name === "" || phone === "" || email === "") {
        alert("");
        return;
    }
    // Validación de teléfono (9 dígitos)
    let phonePattern = /^[0-9]{9}$/;
    if (!phonePattern.test(phone)) {
        alert("");
        return;
    }
    // Crear un nuevo elemento de lista
    let contactList = document.getElementById("contactList");
    let li = document.createElement("li");
    li.textContent = `${name} - ${phone} - ${email}`;
    // Botón para eliminar contacto
    let deleteBtn = document.createElement("button");
    deleteBtn.textContent = "❌";
    deleteBtn.style.marginLeft = "10px";
    deleteBtn.onclick = function() {
        contactList.removeChild(li);
    };
    li.appendChild(deleteBtn);
    contactList.appendChild(li);
    // Limpiar el formulario
    document.getElementById("contactForm").reset();
});
